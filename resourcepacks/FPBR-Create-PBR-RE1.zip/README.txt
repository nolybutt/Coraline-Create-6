learn:
Some PBR textures from SPBR are used, licensed under the GPL 3.0 license
Some PBR textures from SPBR are used, licensed under the GPL 3.0 license
Some PBR textures from SPBR are used, licensed under the GPL 3.0 license



SPBR:
    GitHub: https://github.com/ShulkerSakura/SPBR
    Original Project: Vanilla Normals Renewed - Poudingue
VNR:
    GitHub: https://github.com/Poudingue/Vanilla-Normals-Renewed

使用 SPBR 中的一些 PBR 纹理，根据 GPL 3.0 许可证获得许可
使用 SPBR 中的一些 PBR 纹理，根据 GPL 3.0 许可证获得许可
使用 SPBR 中的一些 PBR 纹理，根据 GPL 3.0 许可证获得许可

SPBR：
GitHub：https://github.com/ShulkerSakura/SPBR
原始项目：Vanilla Normals Renewed - Poudingue
VNR：
GitHub：https://github.com/Poudingue/Vanilla-Normals-Renewed

_______________ ______________________________  __
__  ____/__|__ \___  ____/__<  /__  ___/___  / / /
_  / __  ____/ /__  /_    __  / _____ \ __  /_/ / 
/ /_/ /  _  __/ _  __/    _  /  ____/ / _  __  /  
\____/   /____/ /_/       /_/   /____/  /_/ /_/                   2025 G2F1SH™


以下使用条款在将来可能会发生变化，请以最新版本为准。请关注条款内容的变化。

作者: G2F1SH鱼摆摆

作为作品的使用者，您可以进行以下行为：
1. 将作品文件和其他文件混合，供自己使用。
2. 使用作品创作在线视频，可以通过视频获利。注意，您需要在视频简介中标注此作品的名称，或是在观众提问时回答。
3 传播获取作品的网址“https://afdian.com/a/fishpbr”。因此，您可以转载此作品，但切记不可传播作品文件，只能将玩家引导至此链接。
4 创作基于此作品的拓展功能材质包，并分享给他人使用。注意，您需要在每个版本的分享前向我取得授权。

在未得到我的授权时，您不可进行以下行为：
1. 通过转载、分享、二次发布等方式传播作品文件。
2. 修改作品文件，并分享给他人使用。
3. 将作品文件和其他文件混合，并分享给他人使用。
4. 复制作品的文件，供自己创作其他作品。
5. 直接或间接通过此作品盈利。
6. 将此作品添加到整合包，并发布整合包。
7. 对此作品开展逆向工程、将此作品用于AI训练等

如果您有特殊需求，请先联系我并取得授权。






The following terms of use are subject to change in the future, please refer to the most current version. Please pay attention to the changes to the terms and conditions.

Author: G2F1SH

As a user of a work, you can do the following:
1. Mix the work file with other files for your own use.
2. Create an online video with your work and monetize your video. Note that you'll need to include the title of the work in the video blurb, or answer questions from viewers.
3. Disseminate the "https://afdian.com/a/fishpbr" website for obtaining the work. Therefore, you can reprint this work, but remember that the work file cannot be distributed, and only the player will be directed to this link.
4 Create an extended texture pack based on this work and share it with others. Note that you need to get permission from me before sharing each version.

You may not do the following without my authorization:
1. Disseminate the work documents by reprinting, sharing, republishing, etc.
2. Modify the file and share it with others.
3. Mix the work file with other files and share them with others.
4. Copy the files of the work for your own creation of other works.
5. Directly or indirectly monetize the work.
6. Add this title to the modpack and publish the modpack.
7. Reverse engineer the work and use it for AI training......